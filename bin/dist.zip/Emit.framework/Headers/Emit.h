#import <Foundation/Foundation.h>

//! Project version number for Observable.
FOUNDATION_EXPORT double EmitVersionNumber;

//! Project version string for Observable.
FOUNDATION_EXPORT const unsigned char EmitVersionString[];


